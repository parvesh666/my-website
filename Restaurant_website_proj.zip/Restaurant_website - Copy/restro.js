function validate()
{
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    if(username=='Parvesh' && password==12345)
    {
        window.location.assign('restaurant1.html');
        alert("Login successfully");
    }
    else{
        alert("invalid information");
            document.getElementById("username").disabled=true;
            document.getElementById("password").disabled=true;
            document.getElementById("submit").disabled=true;
          return;
    }
}